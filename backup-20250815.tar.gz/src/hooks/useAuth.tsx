import { createContext, useContext, useEffect, useState } from 'react';
import { User, Session } from '@supabase/supabase-js';
import { supabase } from '@/integrations/supabase/client';
// import { useToast } from '@/hooks/use-toast'; // Temporarily disabled for debugging

interface AuthContextType {
  user: User | null;
  session: Session | null;
  profile: any | null;
  isLoading: boolean;
  signIn: (email: string, password: string) => Promise<{ error?: any }>;
  signUp: (email: string, password: string, referralCode?: string) => Promise<{ error?: any }>;
  signOut: () => Promise<void>;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  // Debug logging to verify component execution
  console.log('AuthProvider rendering');
  
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [profile, setProfile] = useState<any | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  // Temporarily remove useToast to debug
  // const { toast } = useToast();

  const isAdmin = profile?.role === 'admin';

  useEffect(() => {
    // Set up auth state listener
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        setSession(session);
        setUser(session?.user ?? null);
        
        if (session?.user) {
          // Fetch user profile
          setTimeout(async () => {
            const { data: profileData } = await supabase
              .from('profiles')
              .select('*')
              .eq('user_id', session.user.id)
              .single();
            
            setProfile(profileData);
          }, 0);
        } else {
          setProfile(null);
        }
        
        setIsLoading(false);
      }
    );

    // Check for existing session
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setUser(session?.user ?? null);
      
      if (session?.user) {
        setTimeout(async () => {
          const { data: profileData } = await supabase
            .from('profiles')
            .select('*')
            .eq('user_id', session.user.id)
            .single();
          
          setProfile(profileData);
          setIsLoading(false);
        }, 0);
      } else {
        setIsLoading(false);
      }
    });

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    try {
      // Verificar se é o admin master que ainda não tem conta Supabase
      if (email === 'souzamkt0@gmail.com' && password === '123456') {
        // Tentar login normal primeiro
        const { error: authError } = await supabase.auth.signInWithPassword({
          email,
          password,
        });

        // Se não conseguir login normal, redirecionar para registro
        if (authError && authError.message.includes('Invalid login credentials')) {
          // toast({
          //   title: "Admin não registrado",
          //   description: "Faça o registro com este email para criar sua conta admin",
          //   variant: "destructive",
          // });
          console.error("Admin não registrado - redirecionando para registro");
          window.location.href = '/register';
          return { error: authError };
        }
      }

      const { error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        // toast({
        //   title: "Erro no login",
        //   description: error.message,
        //   variant: "destructive",
        // });
        console.error("Erro no login:", error.message);
        return { error };
      }

      // toast({
      //   title: "Login realizado com sucesso!",
      //   description: "Bem-vindo ao Alphabit",
      // });
      console.log("Login realizado com sucesso!");

      return { error: null };
    } catch (error) {
      return { error };
    }
  };

  const signUp = async (email: string, password: string, referralCode?: string) => {
    try {
      const redirectUrl = `${window.location.origin}/dashboard`;
      
      const { error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: redirectUrl,
          data: {
            referral_code: referralCode
          }
        }
      });

      if (error) {
        // toast({
        //   title: "Erro no cadastro",
        //   description: error.message,
        //   variant: "destructive",
        // });
        console.error("Erro no cadastro:", error.message);
        return { error };
      }

      // toast({
      //   title: "Cadastro realizado!",
      //   description: "Verifique seu email para confirmar a conta",
      // });
      console.log("Cadastro realizado!");

      return { error: null };
    } catch (error) {
      return { error };
    }
  };

  const signOut = async () => {
    const { error } = await supabase.auth.signOut();
    if (!error) {
      setUser(null);
      setSession(null);
      setProfile(null);
      // toast({
      //   title: "Logout realizado",
      //   description: "Até logo!",
      // });
      console.log("Logout realizado");
    }
  };

  return (
    <AuthContext.Provider value={{
      user,
      session,
      profile,
      isLoading,
      signIn,
      signUp,
      signOut,
      isAdmin
    }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
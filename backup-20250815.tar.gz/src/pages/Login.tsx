import { useState, useEffect } from "react";
import { useNavigate, Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { useAuth } from "@/hooks/useAuth";
import { Lock, Mail, TrendingUp, Sparkles, ArrowRight } from "lucide-react";

const Login = () => {
  const [isLoading, setIsLoading] = useState(false);
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();
  const { signIn, user } = useAuth();

  // Redirect if already authenticated
  useEffect(() => {
    if (user) {
      navigate("/dashboard");
    }
  }, [user, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    
    const { error } = await signIn(email, password);
    
    if (!error) {
      navigate("/dashboard");
    }
    
    setIsLoading(false);
  };


  return (
    <div className="min-h-screen relative overflow-hidden bg-black">
      {/* Animated Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-black via-gray-900 to-black">
        {/* Subtle grid pattern */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute inset-0 bg-[linear-gradient(rgba(255,255,255,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(255,255,255,0.1)_1px,transparent_1px)] bg-[size:50px_50px]"></div>
        </div>
        
        {/* Floating geometric shapes */}
        <div className="absolute top-20 left-20 w-3 h-3 border border-white/20 rotate-45 animate-pulse"></div>
        <div className="absolute top-40 right-32 w-2 h-2 bg-white/10 rounded-full animate-bounce"></div>
        <div className="absolute bottom-32 left-16 w-4 h-4 border border-white/15 rounded-full animate-ping"></div>
        <div className="absolute bottom-20 right-20 w-3 h-3 bg-white/5 rotate-12 animate-pulse"></div>
        <div className="absolute top-1/3 left-1/4 w-2 h-2 border border-white/20 animate-bounce"></div>
        <div className="absolute top-2/3 right-1/3 w-3 h-3 bg-white/10 rounded-full animate-ping"></div>
      </div>

      {/* Main Content */}
      <div className="relative z-10 min-h-screen flex items-center justify-center p-4">
        <div className="w-full max-w-md">
          {/* User Avatar */}
          <div className="text-center mb-8 animate-fade-in-up">
            <div className="flex justify-center mb-6">
              <div className="relative">
                <div className="w-20 h-20 bg-gradient-to-br from-gray-700 to-gray-800 rounded-full flex items-center justify-center border-2 border-white/20 shadow-2xl">
                   <span className="text-white font-bold text-sm tracking-wider">ALPHABIT</span>
                 </div>
                <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-white/20 rounded-full flex items-center justify-center">
                  <div className="w-3 h-3 bg-white/40 rounded-full animate-pulse"></div>
                </div>
              </div>
            </div>
          </div>

          {/* Login Card */}
          <Card className="bg-gradient-to-b from-gray-900/80 to-black/80 backdrop-blur-xl border-white/10 shadow-2xl animate-fade-in-up animation-delay-400 rounded-3xl overflow-hidden">
            <CardHeader className="text-center pb-2">
              {/* No title, minimalist approach */}
            </CardHeader>
            <CardContent>
              <form onSubmit={handleLogin} className="space-y-6">
                {/* Email Field */}
                <div className="space-y-3 animate-fade-in-up animation-delay-800">
                  <div className="relative group">
                    <Mail className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 group-focus-within:text-white transition-colors duration-200" />
                    <Input
                      id="email"
                      name="email"
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="Email ID"
                      className="pl-12 pr-4 py-4 bg-transparent border-0 border-b-2 border-white/20 text-white placeholder-gray-400 focus:border-white focus:ring-0 transition-all duration-200 rounded-none text-lg"
                      required
                    />
                  </div>
                </div>
                
                {/* Password Field */}
                <div className="space-y-3 animate-fade-in-up animation-delay-900">
                  <div className="relative group">
                    <Lock className="absolute left-4 top-1/2 transform -translate-y-1/2 h-5 w-5 text-gray-400 group-focus-within:text-white transition-colors duration-200" />
                    <Input
                      id="password"
                      name="password"
                      type="password"
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      placeholder="Password"
                      className="pl-12 pr-4 py-4 bg-transparent border-0 border-b-2 border-white/20 text-white placeholder-gray-400 focus:border-white focus:ring-0 transition-all duration-200 rounded-none text-lg"
                      required
                    />
                  </div>
                </div>
                
                {/* Remember me and Forgot Password */}
                <div className="flex items-center justify-between text-sm animate-fade-in-up animation-delay-950">
                  <label className="flex items-center text-gray-300">
                    <input type="checkbox" className="mr-2 rounded border-white/20 bg-transparent" />
                    Lembrar-me
                  </label>
                  <a href="#" className="text-gray-400 hover:text-white transition-colors">
                    Esqueceu a senha?
                  </a>
                </div>
                
                {/* Login Button */}
                <Button 
                  type="submit" 
                  className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white font-semibold py-4 rounded-2xl transform hover:scale-[1.02] transition-all duration-200 shadow-lg hover:shadow-purple-500/25 animate-fade-in-up animation-delay-1000 text-lg" 
                  disabled={isLoading}
                >
                  <span className="flex items-center justify-center">
                    {isLoading ? (
                      <>
                        <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                        Entrando...
                      </>
                    ) : (
                      "LOGIN"
                    )}
                  </span>
                </Button>
              </form>

              {/* Register Section */}
              <div className="mt-8 pt-6 animate-fade-in-up animation-delay-1100">
                <p className="text-center text-gray-400 mb-4 text-sm">
                  Não tem uma conta?
                </p>
                <Link to="/register">
                  <Button 
                    variant="ghost" 
                    className="w-full text-white hover:bg-white/5 transition-all duration-200 transform hover:scale-[1.02] text-sm font-medium"
                  >
                    Criar nova conta
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      <style jsx>{`
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        
        @keyframes gradient-x {
          0%, 100% {
            background-size: 200% 200%;
            background-position: left center;
          }
          50% {
            background-size: 200% 200%;
            background-position: right center;
          }
        }
        
        .animate-fade-in-up {
          animation: fade-in-up 0.6s ease-out forwards;
        }
        
        .animate-gradient-x {
          animation: gradient-x 3s ease infinite;
        }
        
        .animation-delay-200 {
          animation-delay: 0.2s;
        }
        
        .animation-delay-400 {
          animation-delay: 0.4s;
        }
        
        .animation-delay-600 {
          animation-delay: 0.6s;
        }
        
        .animation-delay-700 {
          animation-delay: 0.7s;
        }
        
        .animation-delay-800 {
          animation-delay: 0.8s;
        }
        
        .animation-delay-900 {
          animation-delay: 0.9s;
        }
        
        .animation-delay-1000 {
          animation-delay: 1.0s;
        }
        
        .animation-delay-1100 {
          animation-delay: 1.1s;
        }
      `}</style>
    </div>
  );
};

export default Login;